using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HelloWorld : MonoBehaviour
{
    public sbyte gameName = 125;
    public sbyte age = 2;



    void OnDisable()
    {
        Debug.Log((sbyte)gameName+age);
    }

    void OnEnable()
    {
        Debug.Log("tu tu tu");
    }
}
